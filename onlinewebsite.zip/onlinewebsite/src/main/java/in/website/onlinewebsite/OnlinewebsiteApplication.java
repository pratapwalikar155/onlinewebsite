package in.website.onlinewebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinewebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinewebsiteApplication.class, args);
	}

}
