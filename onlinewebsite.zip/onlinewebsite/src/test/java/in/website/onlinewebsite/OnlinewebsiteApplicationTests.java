package in.website.onlinewebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinewebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
